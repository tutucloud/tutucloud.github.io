# LLM Bridge（浏览器扩展）

通用、项目无关的浏览器消息桥：让网页能把 LLM API 请求转发给本扩展完成（绕过页面 CORS 限制），密钥保存在扩展本地存储、**只写不读**，页面请求只引用 profile。

## 安装（手动加载，开发者模式）

1. 下载并解压本目录（或 zip）。
2. 打开 Chrome，访问 `chrome://extensions/`。
3. 打开右上角「开发者模式」。
4. 点「加载已解压的扩展程序」，选择解压后的目录。

## 页面侧用法

页面通过 `window.postMessage` 与扩展通信，消息统一为 `{ id, type, payload }`，`id` 由页面生成（如 uuid），响应携带同一 `id`。

### 探测扩展是否安装

```js
const id = crypto.randomUUID();
window.postMessage({ id, type: 'llm-bridge.ping' }, location.origin);
// 收到 { id, type: 'llm-bridge.ready' } 即已安装
```

### 写入 / 删除 / 列出条目（只写不读，无 secret.get）

```js
// v0.3.0：记录含 name/model/note 元数据；apiKey 为空表示保留已存密钥（编辑其它字段不需重输）。
window.postMessage({ id, type: 'llm-bridge.secret.set',
  payload: { profile: 'my-entry', baseUrl: 'https://api.example.com/v1', apiKey: 'sk-...',
             name: 'DeepSeek · deepseek-chat', model: 'deepseek-chat', note: '备注' } }, location.origin);
window.postMessage({ id, type: 'llm-bridge.secret.delete', payload: { profile: 'my-entry' } }, location.origin);
window.postMessage({ id, type: 'llm-bridge.secret.list',  payload: {} }, location.origin);
// list 只返回 { profiles: [{ profile, name, baseUrl, model, note, createdAt }] }，不含密钥
```

### 发送 LLM 请求（OpenAI 兼容格式，支持流式与 tool-calling）

```js
window.postMessage({
  id, type: 'llm-bridge.request',
  payload: {
    profile: 'my-api',
    endpoint: 'https://api.example.com/v1/chat/completions', // 必须以该 profile 的 baseUrl 开头
    body: { model: 'gpt-4o', messages: [...], stream: true },
  },
}, location.origin);
```

### GET 请求（v0.2.0 新增，如拉取模型列表 `GET /models`）

```js
window.postMessage({
  id, type: 'llm-bridge.get',
  payload: { profile: 'my-api', endpoint: 'https://api.example.com/v1/models' },
}, location.origin);
// 响应（同一 id）：{ type: 'llm-bridge.response', payload: { status: 200, body: '<响应文本>' } }
```


响应（同一 `id`）：

```jsonc
{ "id": "...", "type": "llm-bridge.response", "payload": { "ok": true } }
{ "id": "...", "type": "llm-bridge.stream", "payload": { "delta": "文本增量", "done": false } }
{ "id": "...", "type": "llm-bridge.stream", "payload": { "toolCalls": [{ "index": 0, "id": "call-1", "name": "fn", "arguments": "分片" }] } }（v0.4.0 起：tool_calls 分片即时透传，不再流末合并）
{ "id": "...", "type": "llm-bridge.stream", "payload": { "done": true } }
{ "id": "...", "type": "llm-bridge.error", "payload": { "message": "...", "code": "NETWORK|HTTP_4XX|NO_PROFILE|ENDPOINT_NOT_ALLOWED|..." } }
```

扩展加载完成后会广播 `{ id: '-', type: 'llm-bridge.ready' }`。

## 安全边界

- 密钥经 `secret.set` 存于扩展 `chrome.storage.local`，**只写不读**；请求引用 profile，由扩展后台注入 `Authorization`。
- 只允许向 profile 中登记过的 `baseUrl` 前缀发请求（`ENDPOINT_NOT_ALLOWED`），防止页面借道访问内网。
- `secret.list` 仅返回元信息（profile、baseUrl、创建时间）。

## 隐私

本扩展不收集任何数据；所有请求仅在你配置的服务与页面之间转发。
