// OneWriter AI Bridge - content script（隔离世界）
// 在页面的 MAIN world 事件与 chrome.runtime 消息之间做中继。
// 注入到页面的 inject.js 无法直接访问 chrome.runtime（隔离边界），
// 因此由本脚本把 'onewriter-*-req' 转发给 background service worker，
// 并把结果以 'onewriter-*-res' 事件回传给页面。

(() => {
  const HANDLERS = {
    'onewriter-ai-req': 'onewriter-ai-request',
    'onewriter-models-req': 'onewriter-models-request',
  };

  for (const [reqEvent, msgType] of Object.entries(HANDLERS)) {
    const resEvent = reqEvent.replace(/-req$/, '-res');
    window.addEventListener(reqEvent, (e) => {
      const { id, requestJson } = e.detail || {};
      if (typeof id === 'undefined' || typeof requestJson !== 'string') return;

      chrome.runtime.sendMessage({ type: msgType, requestJson }, (reply) => {
        const lastError = chrome.runtime.lastError;
        let detail;
        if (lastError) {
          detail = { id, ok: false, error: '扩展通信失败: ' + lastError.message };
        } else if (!reply) {
          detail = { id, ok: false, error: '扩展后台无响应，请确认 OneWriter 扩展已启用' };
        } else if (reply.ok) {
          detail = { id, ok: true, body: reply.body };
        } else if (reply.status > 0) {
          // HTTP 错误也原样回传响应体，页面侧按 OpenAI 错误结构给出可读信息
          detail = { id, ok: false, error: 'AI 服务返回 ' + reply.status + ': ' + reply.body };
        } else {
          detail = { id, ok: false, error: 'AI 请求失败: ' + reply.body };
        }
        window.dispatchEvent(new CustomEvent(resEvent, { detail }));
      });
    });
  }
})();
