// OneWriter AI Bridge - 页面主世界注入脚本（world: MAIN）
// 在页面上下文注入桥接函数，与扩展的隔离世界之间通过 CustomEvent 中继：
//   页面 -> 扩展：'onewriter-*-req'  detail: { id, requestJson }
//   扩展 -> 页面：'onewriter-*-res'  detail: { id, ok, body, error }
// 注入的函数：
//   window.__oneWriterAiBridge(requestJson)    聊天补全，返回 chat/completions 响应 JSON
//   window.__oneWriterModelsBridge(requestJson) 模型列表，返回 GET /models 响应 JSON

(() => {
  if (window.__oneWriterAiBridge && window.__oneWriterModelsBridge) return;

  let seq = 0;
  const pending = new Map();

  const call = (reqEvent, requestJson) => {
    // 先做一次解析校验，保证协议错误在页面侧暴露
    JSON.parse(requestJson);
    const id = ++seq;
    return new Promise((resolve, reject) => {
      pending.set(id, {
        resolve,
        reject,
        // service worker 休眠/扩展被禁用等情况下的兜底超时
        timer: setTimeout(() => {
          pending.delete(id);
          reject(new Error('OneWriter 扩展桥接超时：请确认扩展已启用并刷新页面'));
        }, 150000),
      });
      window.dispatchEvent(new CustomEvent(reqEvent, {
        detail: { id, requestJson },
      }));
    });
  };

  // 每种请求一对事件；响应事件统一回调分发
  const events = {
    __oneWriterAiBridge: 'onewriter-ai',
    __oneWriterModelsBridge: 'onewriter-models',
  };

  for (const [, ns] of Object.entries(events)) {
    window.addEventListener(ns + '-res', (e) => {
      const { id, ok, body, error } = e.detail || {};
      const entry = pending.get(id);
      if (!entry) return;
      pending.delete(id);
      clearTimeout(entry.timer);
      if (ok) {
        entry.resolve(body);
      } else {
        entry.reject(new Error(error || 'AI 代理请求失败'));
      }
    });
  }

  for (const [fnName, ns] of Object.entries(events)) {
    window[fnName] = (requestJson) => call(ns + '-req', requestJson);
  }
})();
