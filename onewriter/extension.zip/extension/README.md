# OneWriter AI Bridge（Chrome 扩展）

Flutter Web 端（`app/`）使用 AI 的必备组件。Web 页面受 CORS 限制无法直连大模型供应商，本扩展在浏览器侧代为发起请求。

## 原理

```
OneWriter (Flutter Web)
  └─ window.__oneWriterAiBridge(requestJson)      ← inject.js 注入（MAIN world，页面可见）
       └─ CustomEvent 'onewriter-ai-req'/'-res'   ← 跨隔离世界中继
            └─ content.js（isolated world）
                 └─ chrome.runtime.sendMessage    ← content script
                      └─ fetch(chat/completions)  ← background service worker
                           （不受页面 CORS 限制，依赖 host_permissions）
```

> 注意：content script 默认运行在隔离世界，直接给它赋值的
> `window.__oneWriterAiBridge` 页面 JS 看不到。因此本扩展拆成两个脚本：
> `inject.js`（`world: "MAIN"`）定义页面可见的桥接函数，`content.js`
> 负责与 background 的 chrome.runtime 通信，两者用 CustomEvent 中继。

## 桥接协议（与 app/lib/core/ai/ai_transport.dart 对应）

- **入口 1**：`window.__oneWriterAiBridge(requestJson: string) => Promise<string>`
  （OpenAI 兼容 `POST chat/completions`）
- **入口 2**：`window.__oneWriterModelsBridge(requestJson: string) => Promise<string>`
  （`GET models`，用于"获取模型列表"）
- **请求**（requestJson 反序列化后）：

  ```json
  {
    "baseUrl": "https://api.example.com/v1/",
    "apiKey": "sk-...",
    "model": "model-name",
    "messages": [{ "role": "user", "content": "..." }],
    "tools": []
  }
  ```

  模型列表入口只需 `baseUrl` 和 `apiKey`。
- **响应**（resolve 值）：OpenAI 兼容响应体 JSON 字符串。
  失败时 reject，错误信息含 HTTP 状态码与响应体。

## 安装（开发模式）

1. Chrome 打开 `chrome://extensions`，开启右上角"开发者模式"。
2. 点击"加载已解压的扩展程序"，选择本 `chromeExtension/` 目录。
3. 刷新 OneWriter Web 页面即可（`run_at: document_start` 保证桥接函数先于应用加载）。

## 验证

在 OneWriter 页面的 DevTools Console 执行：

```js
typeof window.__oneWriterAiBridge // 应输出 "function"
```

## 安全说明

- API Key 仅在本地页面与扩展之间传递，扩展不存储任何数据。
- `host_permissions` 当前为通配 `https://*/*` 以覆盖任意供应商域名；
  正式发布时应收窄到实际使用的供应商域名。
