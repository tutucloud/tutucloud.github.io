// OneWriter AI Bridge - service worker
// 接收 content script 转发的请求，代为 fetch（不受页面 CORS 限制，
// 依赖 manifest 的 host_permissions）：
//   - onewriter-ai-request:     POST chat/completions，返回 OpenAI 兼容响应 JSON
//   - onewriter-models-request: GET  models，返回模型列表响应 JSON

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'onewriter-ai-request') {
    fetchChat(msg.requestJson).then(sendResponse, (e) =>
      sendResponse({ ok: false, status: 0, body: String(e) })
    );
    return true; // 保持消息通道开启以等待异步 sendResponse
  }
  if (msg?.type === 'onewriter-models-request') {
    fetchModels(msg.requestJson).then(sendResponse, (e) =>
      sendResponse({ ok: false, status: 0, body: String(e) })
    );
    return true;
  }
});

async function fetchChat(requestJson) {
  const payload = JSON.parse(requestJson);
  const path = payload.baseUrl.endsWith('/')
    ? payload.baseUrl + 'chat/completions'
    : payload.baseUrl + '/chat/completions';
  const body = {
    model: payload.model,
    messages: payload.messages,
  };
  if (Array.isArray(payload.tools) && payload.tools.length > 0) {
    body.tools = payload.tools;
  }
  const response = await fetch(path, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + payload.apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  return { ok: response.ok, status: response.status, body: await response.text() };
}

async function fetchModels(requestJson) {
  const payload = JSON.parse(requestJson);
  const path = payload.baseUrl.endsWith('/')
    ? payload.baseUrl + 'models'
    : payload.baseUrl + '/models';
  const response = await fetch(path, {
    headers: { 'Authorization': 'Bearer ' + payload.apiKey },
  });
  return { ok: response.ok, status: response.status, body: await response.text() };
}
