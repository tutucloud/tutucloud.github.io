// LLM Bridge · content script
// 页面 ⇄ 扩展 的桥梁：window.postMessage(页面) ⇄ chrome.runtime Port(扩展后台)。
// 协议与项目无关，详见 README.md。
(() => {
  'use strict';

  let port = null;
  const pendingPings = new Set();

  function connect() {
    if (port && !port.error) return;
    port = chrome.runtime.connect({ name: 'llm-bridge' });
    port.onMessage.addListener((msg) => {
      try {
        window.postMessage(msg, window.location.origin);
      } catch (e) {
        // 非 JSON 可结构化克隆的数据不会出现；此分支防御。
      }
    });
    port.onDisconnect.addListener(() => {
      port = null;
    });
  }

  // 加载完成广播（协议约定 id 为 "-"）。
  window.postMessage({ id: '-', type: 'llm-bridge.ready' }, window.location.origin);

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    if (typeof data.type !== 'string' || !data.type.startsWith('llm-bridge.')) return;
    // 只处理页面 → 扩展方向的消息。
    if (['llm-bridge.response', 'llm-bridge.stream', 'llm-bridge.error', 'llm-bridge.ready'].includes(data.type)) {
      return;
    }

    if (data.type === 'llm-bridge.ping') {
      // 已装扩展：立即回 pong（协议用 ready 表示可用）。
      window.postMessage({ id: data.id || '-', type: 'llm-bridge.ready' }, window.location.origin);
      return;
    }

    connect();
    if (!port) return;
    try {
      port.postMessage({ id: data.id, type: data.type, payload: data.payload || {} });
    } catch (e) {
      window.postMessage({
        id: data.id,
        type: 'llm-bridge.error',
        payload: { message: String(e), code: 'BRIDGE' },
      }, window.location.origin);
    }
  });
})();
