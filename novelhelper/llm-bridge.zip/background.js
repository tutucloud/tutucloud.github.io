// LLM Bridge · background service worker
// 职责：
//   1. secret 存取（chrome.storage.local，只写不读——不提供 secret.get）
//   2. 转发 LLM 请求：从 secret 取出 profile 对应密钥注入 Authorization，
//      校验 endpoint 必须以登记过的 baseUrl 开头（防任意借道），
//      解析 SSE 流，把文本增量 / 完整 tool_calls 回传页面。
// 协议与项目无关，详见 README.md。
(() => {
  'use strict';

  const STORE_KEY = 'llmbridge.secrets';

  async function loadSecrets() {
    const obj = await chrome.storage.local.get(STORE_KEY);
    return obj[STORE_KEY] || {};
  }

  async function saveSecrets(secrets) {
    await chrome.storage.local.set({ [STORE_KEY]: secrets });
  }

  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== 'llm-bridge') return;
    port.onMessage.addListener((msg) => handlePortMessage(port, msg));
  });

  async function handlePortMessage(port, msg) {
    if (!msg || typeof msg.id !== 'string') return;
    const { id, type, payload } = msg;
    const reply = (t, p) => port.postMessage({ id, type: t, payload: p });

    try {
      switch (type) {
        case 'llm-bridge.ping':
          reply('llm-bridge.ready', {});
          return;

        case 'llm-bridge.secret.set': {
          // 合并语义：apiKey 为空保留已存密钥（页面只写不读，编辑其它字段不需重输）。
          const secrets = await loadSecrets();
          const existing = secrets[payload.profile];
          secrets[payload.profile] = {
            baseUrl: String(payload.baseUrl || ''),
            apiKey: String(payload.apiKey || '') || (existing && existing.apiKey) || '',
            name: String(payload.name || payload.profile),
            model: String(payload.model || ''),
            note: String(payload.note || ''),
            createdAt: existing ? existing.createdAt : Date.now(),
          };
          await saveSecrets(secrets);
          reply('llm-bridge.response', { ok: true });
          return;
        }

        case 'llm-bridge.secret.delete': {
          const secrets = await loadSecrets();
          delete secrets[payload.profile];
          await saveSecrets(secrets);
          reply('llm-bridge.response', { ok: true });
          return;
        }

        case 'llm-bridge.secret.list': {
          const secrets = await loadSecrets();
          const list = Object.entries(secrets).map(([profile, s]) => ({
            profile,
            name: s.name || profile,
            baseUrl: s.baseUrl,
            model: s.model || '',
            note: s.note || '',
            createdAt: s.createdAt,
          }));
          reply('llm-bridge.response', { profiles: list });
          return;
        }

        case 'llm-bridge.get': {
          const secrets = await loadSecrets();
          const secret = secrets[payload.profile];
          if (!secret) {
            reply('llm-bridge.error', { message: `unknown profile: ${payload.profile}`, code: 'NO_PROFILE' });
            return;
          }
          if (!String(payload.endpoint || '').startsWith(secret.baseUrl)) {
            reply('llm-bridge.error', {
              message: `endpoint not allowed (must start with ${secret.baseUrl})`,
              code: 'ENDPOINT_NOT_ALLOWED',
            });
            return;
          }
          const res = await fetch(payload.endpoint, {
            method: 'GET',
            headers: { Authorization: `Bearer ${secret.apiKey}` },
          });
          const text = await res.text();
          reply('llm-bridge.response', { status: res.status, body: text });
          return;
        }

        case 'llm-bridge.request': {
          const secrets = await loadSecrets();
          const secret = secrets[payload.profile];
          if (!secret) {
            reply('llm-bridge.error', { message: `unknown profile: ${payload.profile}`, code: 'NO_PROFILE' });
            return;
          }
          if (!String(payload.endpoint || '').startsWith(secret.baseUrl)) {
            reply('llm-bridge.error', {
              message: `endpoint not allowed (must start with ${secret.baseUrl})`,
              code: 'ENDPOINT_NOT_ALLOWED',
            });
            return;
          }

          const res = await fetch(payload.endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${secret.apiKey}`,
            },
            body: JSON.stringify(payload.body || {}),
          });

          if (!res.ok) {
            const text = await res.text();
            reply('llm-bridge.error', {
              message: `HTTP ${res.status}: ${text.slice(0, 300)}`,
              code: `HTTP_${res.status}`,
            });
            return;
          }

          await streamSse(res, (event) => port.postMessage({ id, ...event }));
          return;
        }

        default:
          reply('llm-bridge.error', { message: `unknown type: ${type}`, code: 'BAD_TYPE' });
      }
    } catch (e) {
      reply('llm-bridge.error', { message: String(e), code: 'BRIDGE' });
    }
  }

  // 解析 OpenAI 兼容 SSE：文本增量逐条回传；tool_calls 分片累积后一次性回传完整调用。
  async function streamSse(res, emit) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    const toolAcc = new Map();
    let buffer = '';

    const handleData = (data) => {
      if (data === '[DONE]') return;
      let json;
      try {
        json = JSON.parse(data);
      } catch (e) {
        return;
      }
      if (json.error) {
        emit({ type: 'llm-bridge.error', payload: { message: json.error.message || 'server error', code: 'SERVER' } });
        return;
      }
      const choice = json.choices && json.choices[0];
      if (!choice) return;
      const delta = choice.delta || choice.message;
      if (!delta) return;
      if (typeof delta.content === 'string' && delta.content.length > 0) {
        emit({ type: 'llm-bridge.stream', payload: { delta: delta.content, done: false } });
      }
      if (Array.isArray(delta.tool_calls)) {
        for (const tc of delta.tool_calls) {
          const idx = typeof tc.index === 'number' ? tc.index : 0;
          const acc = toolAcc.get(idx) || { id: '', name: '', arguments: '' };
          if (tc.id) acc.id = tc.id;
          if (tc.function) {
            if (tc.function.name) acc.name = tc.function.name;
            if (tc.function.arguments) acc.arguments += tc.function.arguments;
          }
          toolAcc.set(idx, acc);
        }
      }
    };

    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        handleData(trimmed.slice(5).trim());
      }
    }
    if (buffer.trim().startsWith('data:')) {
      handleData(buffer.trim().slice(5).trim());
    }

    if (toolAcc.size > 0) {
      const calls = [...toolAcc.entries()]
        .sort((a, b) => a[0] - b[0])
        .map(([, c]) => ({ id: c.id, name: c.name, arguments: c.arguments }));
      emit({ type: 'llm-bridge.stream', payload: { toolCalls: calls } });
    }
    emit({ type: 'llm-bridge.stream', payload: { done: true } });
  }
})();
